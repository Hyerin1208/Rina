// main 모델 만들기
const Sequelize = require("sequelize");

// 모델을 만들고 exports
module.exports = class Main extends Sequelize.Model {
  static init(sequelize) {
    // 테이블 설정
    //시퀄라이즈는id를 기본키 디폴트값
    return super.init(
      {
        Title: {
          type: Sequelize.STRING(50),
          allowNull: false,
          unique: true,
        },
        ReleaseDate: {
          type: Sequelize.STRING(10),
          allowNull: false,
        },
        RunningTime: {
          type: Sequelize.STRING(10),
          allowNull: false,
        },
        Cast: {
          type: Sequelize.STRING(50),
          allowNull: false,
        },
        Poster: {
          type: Sequelize.BLOB,
          allowNull: true,
        },
      },
      {
        sequelize,
        timestamps: false,
        underscored: false,
        modelName: "Main",
        tablename: "mains",
        paranoid: false,
        charset: "utf8",
        collate: "utf8_general_ci",
      }
    );
  }
};

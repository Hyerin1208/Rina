document.querySelectorAll("#main-list tr").forEach((el) => {
  el.addEventListener("click", function () {
    const id = el.querySelector("td").textContent;
    getComment(id);
  });
});
//main페이지 로딩
async function getUser() {
  try {
    const res = await axios.get("/mains");
    const mains = res.data;
    console.log(mains);
    const tbody = document.querySelector("#main-list tbody");
    tbody.innerHTML = "";
    mains.map(function (main) {
      const row = document.createElement("tr");
      row.addEventListener("click", () => {
        getComment(main.id);
      });
      //로우 셀 추가
      let td = document.createElement("td");
      td.textContent = main.id;
      row.appendChild(td);
      td = document.createElement("td");
      td.textContent = main.Title;
      row.appendChild(td);
      td = document.createElement("td");
      td.textContent = main.ReleaseDate;
      row.appendChild(td);
      td = document.createElement("td");
      td.textContent = main.RunningTime;
      row.appendChild(td);
      td = document.createElement("td");
      td.textContent = main.Cast;
      row.appendChild(td);
      td = document.createElement("td");
    });
  } catch (err) {
    console.error(err);
  }
  e.target.mainTitle.value = "";
}

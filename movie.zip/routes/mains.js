const express = require("express");
const Main = require("../models/main");

const router = express.Router();

router.route("/").get(async (req, res, next) => {
  try {
    const mains = await Main.findAll();
    res.json(mains);
    console.log(mains);
  } catch (err) {
    console.error(err);
    next(err);
  }
});
// .post(async (req, res, next) => {
//   try {
//     const main = await Main.create({
//       Title: req.body.Title,
//       ReleaseDate: req.body.ReleaseDate,
//       RunningTime: req.body.RunningTime,
//       Cast: req.body.Cast,
//     });
//     console.log(main);
//     res.status(201).json(main);
//   } catch (err) {
//     console.error(err);
//     next(err);
//   }
// });

module.exports = router;

const express = require("express");
const Main = require("../models/main");

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const mains = await Main.findAll();
    res.render("sequelize", { mains });
  } catch (err) {
    console.error(err);
    next(err);
  }
});

module.exports = router;
